package com.commission.commission.controller;

import com.commission.commission.entity.CommissionRule;
import com.commission.commission.service.commissionRuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class commissionRuleController {
    @Autowired
    com.commission.commission.service.commissionRuleService commissionRuleService;

    @PostMapping("admin/update/commissionRule")
    public List<CommissionRule> update(@RequestBody CommissionRule commissionRule)
    {
        return commissionRuleService.update(commissionRule);
    }
    @GetMapping("/admin/getAllCommissionRule")
    public List<CommissionRule> getAllCommissionRule(){
        return commissionRuleService.getAllCommissionRule();
    }
}

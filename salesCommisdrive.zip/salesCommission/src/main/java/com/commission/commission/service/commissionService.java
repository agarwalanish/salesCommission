package com.commission.commission.service;

import com.commission.commission.Repo.*;
import com.commission.commission.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class commissionService {
    @Autowired
    salesLineItemService salesLineItemService;
    @Autowired
    productRepo productRepo;
    @Autowired
    productTypeRepo productTypeRepo;
    @Autowired
    com.commission.commission.Repo.commissionRepo commissionRepo;
    @Autowired
    com.commission.commission.Repo.salesPersonRepo salesPersonRepo;


    @Autowired
    commissionRuleRepo commissionRuleRepo;
    public Double commission(int sid, int month)
    {

        System.out.println(sid);
        List<SalesLineItem> sales = salesLineItemService.salesByMonth(sid, month);
        Double totalCommission= 0.0;
        Double old_commission=0.0;
        for (int x=0;x<sales.size();x++)
        {
            int pid = sales.get(x).getPid();
            String productType = (productRepo.findById(pid)).get().getProductType();
            List<ProductType> productTypeList = productTypeRepo.findByPtype(productType);
            for (int y=0;y<productTypeList.size();y++)
            {
                if(sales.get(x).getAmount()<=productTypeList.get(y).getPrice())
                {
                    totalCommission=totalCommission+(productTypeList.get(y).getCommission()*sales.get(x).getAmount());
                        break;
                }
            }
        }
        System.out.println("Total"+totalCommission);
        if(commissionRepo.findBySidAndMonth(sid,month)!=null)
        {
             old_commission = commissionRepo.findBySidAndMonth(sid, month).getCommission();
             System.out.println("Old"+old_commission);
             Commission dummy = commissionRepo.findBySidAndMonth(sid,month);
             dummy.setCommission(totalCommission);
             commissionRepo.save(dummy);
        }
        else {
            Commission commission = new Commission();
            commission.setSid(sid);
            commission.setMonth(month);
            commission.setCommission(totalCommission);
            commissionRepo.save(commission);
        }
        Optional<SalesPerson> byId = salesPersonRepo.findById(sid);
        //System.out.println(byId.get().getCityID());
        if(byId.get().getCityID()!=0)
        {
            if(commissionRepo.findBySidAndMonth(byId.get().getCityID(),month)!=null)
            {
                Commission dummy = commissionRepo.findBySidAndMonth(byId.get().getCityID(), month);
                dummy.setCommission((totalCommission*commissionRuleRepo.findById(0).get().getCity_Rule())+(commissionRepo.findBySidAndMonth(byId.get().getCityID(), month).getCommission())-(old_commission*commissionRuleRepo.findById(0).get().getCity_Rule()));
                commissionRepo.save(dummy);
            }
            else
            {
                Commission cityCommission = new Commission();
                cityCommission.setSid(byId.get().getCityID());
                cityCommission.setMonth(month);
                cityCommission.setCommission(totalCommission*commissionRuleRepo.findById(0).get().getCity_Rule());
                commissionRepo.save(cityCommission);
            }
//            System.out.println(commission.getCommission()+"  -----  "+commission.getSID());
        }
        if(byId.get().getStateID()!=0)
        {
            if(commissionRepo.findBySidAndMonth(byId.get().getStateID(),month)!=null)
            {
                Commission dummy = commissionRepo.findBySidAndMonth(byId.get().getStateID(), month);
                dummy.setCommission((totalCommission*commissionRuleRepo.findById(0).get().getState_Rule())+(commissionRepo.findBySidAndMonth(byId.get().getStateID(), month).getCommission())-(old_commission*commissionRuleRepo.findById(0).get().getState_Rule()));
                commissionRepo.save(dummy);
            }
            else
            {
                Commission stateCommission = new Commission();
                stateCommission.setSid(byId.get().getStateID());
                stateCommission.setMonth(month);
                stateCommission.setCommission(totalCommission*commissionRuleRepo.findById(0).get().getState_Rule());
                commissionRepo.save(stateCommission);
            }
//            System.out.println(commission.getCommission()+"  -----  "+commission.getSID());
        }
        if(byId.get().getCountryID()!=0)
        {
            if(commissionRepo.findBySidAndMonth(byId.get().getCountryID(),month)!=null)
            {
                Commission dummy = commissionRepo.findBySidAndMonth(byId.get().getCountryID(), month);
                dummy.setCommission((totalCommission*commissionRuleRepo.findById(0).get().getCountry_Rule())+(commissionRepo.findBySidAndMonth(byId.get().getCountryID(), month).getCommission())-(old_commission*commissionRuleRepo.findById(0).get().getCountry_Rule()));
                commissionRepo.save(dummy);
            }
            else
            {
                Commission countryCommission = new Commission();
                countryCommission.setSid(byId.get().getCountryID());
                countryCommission.setMonth(month);
                countryCommission.setCommission(totalCommission*commissionRuleRepo.findById(0).get().getCountry_Rule());
                commissionRepo.save(countryCommission);
            }
//            System.out.println(commission.getCommission()+"  -----  "+commission.getSID());
        }
        return totalCommission;
    }
}

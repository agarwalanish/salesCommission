package com.commission.commission;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommissionApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommissionApplication.class, args);
	}

}

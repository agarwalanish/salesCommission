package com.commission.commission.controller;

import com.commission.commission.entity.ProductType;
import com.commission.commission.service.productTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class productTypeController {

    @Autowired
    com.commission.commission.service.productTypeService productTypeService;

    @PostMapping("/admin/update/commissionPercentage")
    public List<ProductType> updateCommissionPercentage(@RequestBody ProductType producttype)
    {
        return productTypeService.updateCommissionPercentage(producttype);
    }

    @GetMapping("/admin/getProductType")
    public List<ProductType> getProductType(){

        return productTypeService.getProductType();
    }

}
